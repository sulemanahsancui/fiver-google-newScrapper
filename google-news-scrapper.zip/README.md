# Project Name
  Google news website autofill form response data scrapper 
## Description of your project.
  scrapp data and store it into xls sheet

## Prerequisites

- ## Node.js (version X.X.X or higher)
   To install node into your computer just go to this website 
   ## LINK  ::  https://nodejs.org/en
- ## Yarn (version X.X.X or higher)
  After install node js just run this command into your command window 
     ## npm install --global yarn 

## Installation

  ## Open Project into code editor and run this command 
  command ::   yarn 

## After run above command to start project run thus command 
    yarn start 


## All done now you can enter text into form and script run and get data and store it into xls file into your project directory 